// --- وظائف الواجهات المصلحة تماماً ---

const ui = {

    show: (id) => {

        // إخفاء جميع الواجهات أولاً

        const screens = ['screen-start', 'screen-skins', 'screen-settings', 'screen-pause', 'screen-death'];

        screens.forEach(s => {

            const el = document.getElementById(s);

            if(el) el.classList.add('hidden');

        });

        // إظهار الواجهة المطلوبة

        const target = document.getElementById(id);

        if(target) target.classList.remove('hidden');

        

        // تحديث البيانات المعروضة

        if(id === 'screen-start' || id === 'screen-skins') {

            document.getElementById('total-coins-display').innerText = storage.totalCoins;

            ui.updateSkinUI();

        }

    },

    

    updateSkinUI: () => {

        document.querySelectorAll('.skin-card').forEach(card => {

            const id = card.id.split('-')[1];

            card.classList.toggle('selected', storage.currentSkin === id);

            if(storage.unlockedSkins.includes(id)) {

                const priceTag = card.querySelector('.price');

                if(priceTag) priceTag.innerText = "UNLOCKED";

            }

        });

    }

};

// --- وظائف اللعبة المصلحة (Try Again & Main Menu) ---

// زر TRY AGAIN في شاشة الموت

game.retry = function() {

    // إخفاء الواجهة فوراً

    document.getElementById('screen-death').classList.add('hidden');

    // إعادة تحميل الصفحة بالكامل لضمان تصفير كل شيء (أكثر الطرق ضماناً)

    window.location.replace(window.location.pathname + window.location.search + window.location.hash);

};

// زر MAIN MENU في شاشة الإيقاف

game.quit = function() {

    // التأكد من حفظ العملات قبل الخروج

    storage.totalCoins += this.coins;

    localStorage.setItem('mario_coins', storage.totalCoins);

    // إعادة تشغيل اللعبة للذهاب للقائمة الرئيسية

    window.location.replace(window.location.pathname);

};

// دالة الموت المحدثة

game.die = function() {

    if(this.state === 'DEAD') return; // منع التكرار

    this.state = 'DEAD';

    music.pause();

    

    // حفظ النقاط

    storage.totalCoins += this.coins;

    localStorage.setItem('mario_coins', storage.totalCoins);

    

    // إظهار شاشة الموت

    ui.show('screen-death');

};

// --- تحديث الأزرار في HTML لتعمل مع الدوال الجديدة ---

// تأكد أن الأزرار في الـ HTML مكتوبة بهذا الشكل:

// <div class="btn" onclick="game.retry()">TRY AGAIN</div>

// <div class="btn red-btn" onclick="game.quit()">MAIN MENU</div>

    // دالة الموت المحدثة لضمان عمل زر Try Again

    game.die = function() {

        this.state = 'DEAD';

        music.pause();

        

        // حفظ العملات في الذاكرة الدائمة

        storage.totalCoins += this.coins;

        localStorage.setItem('mario_coins', storage.totalCoins);

        

        // إظهار واجهة الموت

        const deathScreen = document.getElementById('screen-death');

        deathScreen.classList.remove('hidden');

        

        // التأكد من أن الزر سيعيد تحميل اللعبة فعلياً

        const retryBtn = deathScreen.querySelector('.btn');

        retryBtn.onclick = function() {

            window.location.href = window.location.href; // طريقة أقوى لإعادة التحميل

        };

    };

    // تأكد أيضاً من تحديث دالة startGame لمنع أي تعليق

    game.start = function() {

        this.state = 'PLAYING';

        this.coins = 0;

        if(this.musicOn) {

            music.currentTime = 0; // بدء الأغنية من البداية

            music.play().catch(e => console.log("Music auto-play blocked"));

        }

        document.getElementById('screen-start').classList.add('hidden');

        document.getElementById('controls').classList.remove('hidden');

        requestAnimationFrame(loop);

    };

